--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 16.0
-- Dumped by pg_dump version 16.0

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE ikealatest;
--
-- Name: ikealatest; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE ikealatest WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'Thai_Thailand.874';


ALTER DATABASE ikealatest OWNER TO postgres;

\connect ikealatest

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: Address; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Address" (
    address_id character(10) NOT NULL,
    address text,
    province text,
    district text,
    zip character(5),
    telephone character(10)
);


ALTER TABLE public."Address" OWNER TO postgres;

--
-- Name: Branch; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Branch" (
    branch_id character(2) NOT NULL,
    branch_name character varying(50) NOT NULL,
    address text,
    street text,
    district text,
    province text,
    zip character(5),
    branch_phone character(10),
    branch_email text,
    open_office_hour time without time zone NOT NULL,
    close_office_hour time without time zone NOT NULL
);


ALTER TABLE public."Branch" OWNER TO postgres;

--
-- Name: CatSubCat; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."CatSubCat" (
    "Category_category_id" character(5) NOT NULL,
    "SubCategory_1_subcategory_id" character(5) NOT NULL
);


ALTER TABLE public."CatSubCat" OWNER TO postgres;

--
-- Name: Category; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Category" (
    category_id character(5) NOT NULL,
    category_name text NOT NULL
);


ALTER TABLE public."Category" OWNER TO postgres;

--
-- Name: Color; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Color" (
    color_id character(6) NOT NULL,
    color_name character varying(50) NOT NULL
);


ALTER TABLE public."Color" OWNER TO postgres;

--
-- Name: Employee; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Employee" (
    employee_id character(6) NOT NULL,
    emp_first_name character varying(50) NOT NULL,
    emp_last_name character varying(50) NOT NULL,
    telephone character(10),
    address text,
    street text,
    district text,
    province text,
    zip character(5),
    position_id character(4) NOT NULL,
    branch_id character(2)
);


ALTER TABLE public."Employee" OWNER TO postgres;

--
-- Name: Giftcard; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Giftcard" (
    giftcard_id character(10) NOT NULL,
    amount integer NOT NULL,
    publish_date timestamp without time zone NOT NULL,
    expire_date timestamp without time zone NOT NULL
);


ALTER TABLE public."Giftcard" OWNER TO postgres;

--
-- Name: Member; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Member" (
    member_id character(10) NOT NULL,
    first_name character varying(50) NOT NULL,
    last_name character varying(50) NOT NULL,
    date_of_birth timestamp without time zone NOT NULL,
    password text NOT NULL,
    telephone character(10) NOT NULL,
    member_date timestamp without time zone NOT NULL
);


ALTER TABLE public."Member" OWNER TO postgres;

--
-- Name: MemberAddress; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."MemberAddress" (
    mem_add_id integer NOT NULL,
    address_id character(10) NOT NULL,
    member_id character(10) NOT NULL,
    "isDefault" boolean
);


ALTER TABLE public."MemberAddress" OWNER TO postgres;

--
-- Name: MemberAddress_mem_add_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."MemberAddress_mem_add_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."MemberAddress_mem_add_id_seq" OWNER TO postgres;

--
-- Name: MemberAddress_mem_add_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."MemberAddress_mem_add_id_seq" OWNED BY public."MemberAddress".mem_add_id;


--
-- Name: Order; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Order" (
    order_id character(18) NOT NULL,
    order_date timestamp without time zone NOT NULL,
    payment_id character(2) NOT NULL,
    order_type_id character(2) NOT NULL,
    employee_id character(6),
    shipping_method_id character(2),
    mem_add_id integer,
    giftcard_id character(10),
    member_id character(10)
);


ALTER TABLE public."Order" OWNER TO postgres;

--
-- Name: OrderStatus; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."OrderStatus" (
    order_id character(18) NOT NULL,
    "timestamp" timestamp without time zone NOT NULL,
    status_id character(1) NOT NULL
);


ALTER TABLE public."OrderStatus" OWNER TO postgres;

--
-- Name: OrderType; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."OrderType" (
    order_type_id character(2) NOT NULL,
    order_type_desc text NOT NULL
);


ALTER TABLE public."OrderType" OWNER TO postgres;

--
-- Name: Parameter; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Parameter" (
);


ALTER TABLE public."Parameter" OWNER TO postgres;

--
-- Name: Payment; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Payment" (
    payment_id character(2) NOT NULL,
    payment_desc text NOT NULL
);


ALTER TABLE public."Payment" OWNER TO postgres;

--
-- Name: PointLog; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."PointLog" (
    log_id integer NOT NULL,
    movement integer NOT NULL,
    remark text NOT NULL
);


ALTER TABLE public."PointLog" OWNER TO postgres;

--
-- Name: Position; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Position" (
    position_id character(4) NOT NULL,
    position_name character varying(50) NOT NULL
);


ALTER TABLE public."Position" OWNER TO postgres;

--
-- Name: PriceHistory; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."PriceHistory" (
    product_id character(10) NOT NULL,
    start_date timestamp without time zone NOT NULL,
    end_date timestamp without time zone,
    normal_price integer NOT NULL,
    membership_price integer
);


ALTER TABLE public."PriceHistory" OWNER TO postgres;

--
-- Name: Product; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Product" (
    product_id character(10) NOT NULL,
    product_name_eng character varying(100) NOT NULL,
    descr text,
    width numeric(5,2),
    length numeric(5,2),
    height numeric(5,2),
    color_id character(6),
    "isRecommended" boolean
);


ALTER TABLE public."Product" OWNER TO postgres;

--
-- Name: ProductCategory; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."ProductCategory" (
    product_id character(10) NOT NULL,
    subcategory_id character(5) NOT NULL
);


ALTER TABLE public."ProductCategory" OWNER TO postgres;

--
-- Name: ProductOrder; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."ProductOrder" (
    "Product_Order_id" bigint NOT NULL,
    "Product_product_id" character(10) NOT NULL,
    "Order_order_id" character(18) NOT NULL,
    qty integer NOT NULL,
    branch_id character(2) NOT NULL
);


ALTER TABLE public."ProductOrder" OWNER TO postgres;

--
-- Name: ProductOrderReturn; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."ProductOrderReturn" (
    product_order_id bigint NOT NULL,
    return_date timestamp without time zone NOT NULL,
    qty integer NOT NULL,
    reason text
);


ALTER TABLE public."ProductOrderReturn" OWNER TO postgres;

--
-- Name: Promotion; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Promotion" (
    promotion_id character(3) NOT NULL,
    promotion_type_id character(2) NOT NULL,
    descr text,
    start_date timestamp without time zone NOT NULL,
    end_date timestamp without time zone NOT NULL
);


ALTER TABLE public."Promotion" OWNER TO postgres;

--
-- Name: PromotionType; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."PromotionType" (
    promotion_type_id character(2) NOT NULL,
    descr text
);


ALTER TABLE public."PromotionType" OWNER TO postgres;

--
-- Name: ShippingMethod; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."ShippingMethod" (
    shipping_method_id character(2) NOT NULL,
    shipping_method_desc text NOT NULL
);


ALTER TABLE public."ShippingMethod" OWNER TO postgres;

--
-- Name: Status; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Status" (
    status_id character(1) NOT NULL,
    status_description character varying(50) NOT NULL
);


ALTER TABLE public."Status" OWNER TO postgres;

--
-- Name: Stock; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Stock" (
    stock_record_id bigint NOT NULL,
    product_id character(10) NOT NULL,
    warehouse_id character(2) NOT NULL,
    qty integer NOT NULL,
    recieve_date timestamp without time zone NOT NULL
);


ALTER TABLE public."Stock" OWNER TO postgres;

--
-- Name: SubCategory_1; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."SubCategory_1" (
    subcategory_id character(5) NOT NULL,
    descr text NOT NULL
);


ALTER TABLE public."SubCategory_1" OWNER TO postgres;

--
-- Name: SubCategory_2; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."SubCategory_2" (
    subcategory_id character varying(5) NOT NULL,
    descr text NOT NULL
);


ALTER TABLE public."SubCategory_2" OWNER TO postgres;

--
-- Name: SubCategory_2_1; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."SubCategory_2_1" (
    "SubCat_2_id" character varying(5) NOT NULL,
    "SubCat_1_id" character(5) NOT NULL
);


ALTER TABLE public."SubCategory_2_1" OWNER TO postgres;

--
-- Name: SubCategory_3; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."SubCategory_3" (
    subcategory_id character(5) NOT NULL,
    descr text NOT NULL
);


ALTER TABLE public."SubCategory_3" OWNER TO postgres;

--
-- Name: SubCategory_3_2; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."SubCategory_3_2" (
    "SubCat_3_id" character(5) NOT NULL,
    "SubCat_2_id" character varying(5) NOT NULL
);


ALTER TABLE public."SubCategory_3_2" OWNER TO postgres;

--
-- Name: SubCategory_4; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."SubCategory_4" (
    subcategory_id character(5) NOT NULL,
    descr text NOT NULL
);


ALTER TABLE public."SubCategory_4" OWNER TO postgres;

--
-- Name: SubCategory_4_3; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."SubCategory_4_3" (
    "SubCat_4_id" character(5) NOT NULL,
    "SubCat_3_id" character(5) NOT NULL
);


ALTER TABLE public."SubCategory_4_3" OWNER TO postgres;

--
-- Name: Warehouse; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Warehouse" (
    warehouse_id character(2) NOT NULL,
    warehouse_name character varying(50) NOT NULL,
    address text,
    street text,
    province text,
    district text,
    zip character(6),
    warehouse_phone character(10),
    warehouse_email text,
    open_office_hour time without time zone,
    close_office_hour time without time zone
);


ALTER TABLE public."Warehouse" OWNER TO postgres;

--
-- Name: WarehouseBranch; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."WarehouseBranch" (
    warehouse_id character(2) NOT NULL,
    branch_id character(2) NOT NULL,
    wb_id integer NOT NULL
);


ALTER TABLE public."WarehouseBranch" OWNER TO postgres;

--
-- Name: WarehouseBranch_wb_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."WarehouseBranch_wb_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."WarehouseBranch_wb_id_seq" OWNER TO postgres;

--
-- Name: WarehouseBranch_wb_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."WarehouseBranch_wb_id_seq" OWNED BY public."WarehouseBranch".wb_id;


--
-- Name: Warranty; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Warranty" (
    warranty_id character(5) NOT NULL,
    product_id character(10) NOT NULL,
    warranty_length_month integer
);


ALTER TABLE public."Warranty" OWNER TO postgres;

--
-- Name: WarrantyRecord; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."WarrantyRecord" (
    warranty_record_id bigint NOT NULL,
    order_id character(18) NOT NULL,
    product_id character(10) NOT NULL,
    warranty_record_date timestamp without time zone NOT NULL
);


ALTER TABLE public."WarrantyRecord" OWNER TO postgres;

--
-- Name: MemberAddress mem_add_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."MemberAddress" ALTER COLUMN mem_add_id SET DEFAULT nextval('public."MemberAddress_mem_add_id_seq"'::regclass);


--
-- Name: WarehouseBranch wb_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."WarehouseBranch" ALTER COLUMN wb_id SET DEFAULT nextval('public."WarehouseBranch_wb_id_seq"'::regclass);


--
-- Data for Name: Address; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Address" (address_id, address, province, district, zip, telephone) FROM stdin;
\.
COPY public."Address" (address_id, address, province, district, zip, telephone) FROM '$$PATH$$/5037.dat';

--
-- Data for Name: Branch; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Branch" (branch_id, branch_name, address, street, district, province, zip, branch_phone, branch_email, open_office_hour, close_office_hour) FROM stdin;
\.
COPY public."Branch" (branch_id, branch_name, address, street, district, province, zip, branch_phone, branch_email, open_office_hour, close_office_hour) FROM '$$PATH$$/5038.dat';

--
-- Data for Name: CatSubCat; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."CatSubCat" ("Category_category_id", "SubCategory_1_subcategory_id") FROM stdin;
\.
COPY public."CatSubCat" ("Category_category_id", "SubCategory_1_subcategory_id") FROM '$$PATH$$/5039.dat';

--
-- Data for Name: Category; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Category" (category_id, category_name) FROM stdin;
\.
COPY public."Category" (category_id, category_name) FROM '$$PATH$$/5040.dat';

--
-- Data for Name: Color; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Color" (color_id, color_name) FROM stdin;
\.
COPY public."Color" (color_id, color_name) FROM '$$PATH$$/5041.dat';

--
-- Data for Name: Employee; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Employee" (employee_id, emp_first_name, emp_last_name, telephone, address, street, district, province, zip, position_id, branch_id) FROM stdin;
\.
COPY public."Employee" (employee_id, emp_first_name, emp_last_name, telephone, address, street, district, province, zip, position_id, branch_id) FROM '$$PATH$$/5042.dat';

--
-- Data for Name: Giftcard; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Giftcard" (giftcard_id, amount, publish_date, expire_date) FROM stdin;
\.
COPY public."Giftcard" (giftcard_id, amount, publish_date, expire_date) FROM '$$PATH$$/5043.dat';

--
-- Data for Name: Member; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Member" (member_id, first_name, last_name, date_of_birth, password, telephone, member_date) FROM stdin;
\.
COPY public."Member" (member_id, first_name, last_name, date_of_birth, password, telephone, member_date) FROM '$$PATH$$/5044.dat';

--
-- Data for Name: MemberAddress; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."MemberAddress" (mem_add_id, address_id, member_id, "isDefault") FROM stdin;
\.
COPY public."MemberAddress" (mem_add_id, address_id, member_id, "isDefault") FROM '$$PATH$$/5071.dat';

--
-- Data for Name: Order; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Order" (order_id, order_date, payment_id, order_type_id, employee_id, shipping_method_id, mem_add_id, giftcard_id, member_id) FROM stdin;
\.
COPY public."Order" (order_id, order_date, payment_id, order_type_id, employee_id, shipping_method_id, mem_add_id, giftcard_id, member_id) FROM '$$PATH$$/5045.dat';

--
-- Data for Name: OrderStatus; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."OrderStatus" (order_id, "timestamp", status_id) FROM stdin;
\.
COPY public."OrderStatus" (order_id, "timestamp", status_id) FROM '$$PATH$$/5046.dat';

--
-- Data for Name: OrderType; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."OrderType" (order_type_id, order_type_desc) FROM stdin;
\.
COPY public."OrderType" (order_type_id, order_type_desc) FROM '$$PATH$$/5047.dat';

--
-- Data for Name: Parameter; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Parameter"  FROM stdin;
\.
COPY public."Parameter"  FROM '$$PATH$$/5048.dat';

--
-- Data for Name: Payment; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Payment" (payment_id, payment_desc) FROM stdin;
\.
COPY public."Payment" (payment_id, payment_desc) FROM '$$PATH$$/5049.dat';

--
-- Data for Name: PointLog; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."PointLog" (log_id, movement, remark) FROM stdin;
\.
COPY public."PointLog" (log_id, movement, remark) FROM '$$PATH$$/5050.dat';

--
-- Data for Name: Position; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Position" (position_id, position_name) FROM stdin;
\.
COPY public."Position" (position_id, position_name) FROM '$$PATH$$/5051.dat';

--
-- Data for Name: PriceHistory; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."PriceHistory" (product_id, start_date, end_date, normal_price, membership_price) FROM stdin;
\.
COPY public."PriceHistory" (product_id, start_date, end_date, normal_price, membership_price) FROM '$$PATH$$/5052.dat';

--
-- Data for Name: Product; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Product" (product_id, product_name_eng, descr, width, length, height, color_id, "isRecommended") FROM stdin;
\.
COPY public."Product" (product_id, product_name_eng, descr, width, length, height, color_id, "isRecommended") FROM '$$PATH$$/5053.dat';

--
-- Data for Name: ProductCategory; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."ProductCategory" (product_id, subcategory_id) FROM stdin;
\.
COPY public."ProductCategory" (product_id, subcategory_id) FROM '$$PATH$$/5069.dat';

--
-- Data for Name: ProductOrder; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."ProductOrder" ("Product_Order_id", "Product_product_id", "Order_order_id", qty, branch_id) FROM stdin;
\.
COPY public."ProductOrder" ("Product_Order_id", "Product_product_id", "Order_order_id", qty, branch_id) FROM '$$PATH$$/5054.dat';

--
-- Data for Name: ProductOrderReturn; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."ProductOrderReturn" (product_order_id, return_date, qty, reason) FROM stdin;
\.
COPY public."ProductOrderReturn" (product_order_id, return_date, qty, reason) FROM '$$PATH$$/5055.dat';

--
-- Data for Name: Promotion; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Promotion" (promotion_id, promotion_type_id, descr, start_date, end_date) FROM stdin;
\.
COPY public."Promotion" (promotion_id, promotion_type_id, descr, start_date, end_date) FROM '$$PATH$$/5073.dat';

--
-- Data for Name: PromotionType; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."PromotionType" (promotion_type_id, descr) FROM stdin;
\.
COPY public."PromotionType" (promotion_type_id, descr) FROM '$$PATH$$/5056.dat';

--
-- Data for Name: ShippingMethod; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."ShippingMethod" (shipping_method_id, shipping_method_desc) FROM stdin;
\.
COPY public."ShippingMethod" (shipping_method_id, shipping_method_desc) FROM '$$PATH$$/5057.dat';

--
-- Data for Name: Status; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Status" (status_id, status_description) FROM stdin;
\.
COPY public."Status" (status_id, status_description) FROM '$$PATH$$/5058.dat';

--
-- Data for Name: Stock; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Stock" (stock_record_id, product_id, warehouse_id, qty, recieve_date) FROM stdin;
\.
COPY public."Stock" (stock_record_id, product_id, warehouse_id, qty, recieve_date) FROM '$$PATH$$/5059.dat';

--
-- Data for Name: SubCategory_1; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."SubCategory_1" (subcategory_id, descr) FROM stdin;
\.
COPY public."SubCategory_1" (subcategory_id, descr) FROM '$$PATH$$/5060.dat';

--
-- Data for Name: SubCategory_2; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."SubCategory_2" (subcategory_id, descr) FROM stdin;
\.
COPY public."SubCategory_2" (subcategory_id, descr) FROM '$$PATH$$/5061.dat';

--
-- Data for Name: SubCategory_2_1; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."SubCategory_2_1" ("SubCat_2_id", "SubCat_1_id") FROM stdin;
\.
COPY public."SubCategory_2_1" ("SubCat_2_id", "SubCat_1_id") FROM '$$PATH$$/5062.dat';

--
-- Data for Name: SubCategory_3; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."SubCategory_3" (subcategory_id, descr) FROM stdin;
\.
COPY public."SubCategory_3" (subcategory_id, descr) FROM '$$PATH$$/5063.dat';

--
-- Data for Name: SubCategory_3_2; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."SubCategory_3_2" ("SubCat_3_id", "SubCat_2_id") FROM stdin;
\.
COPY public."SubCategory_3_2" ("SubCat_3_id", "SubCat_2_id") FROM '$$PATH$$/5064.dat';

--
-- Data for Name: SubCategory_4; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."SubCategory_4" (subcategory_id, descr) FROM stdin;
\.
COPY public."SubCategory_4" (subcategory_id, descr) FROM '$$PATH$$/5065.dat';

--
-- Data for Name: SubCategory_4_3; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."SubCategory_4_3" ("SubCat_4_id", "SubCat_3_id") FROM stdin;
\.
COPY public."SubCategory_4_3" ("SubCat_4_id", "SubCat_3_id") FROM '$$PATH$$/5066.dat';

--
-- Data for Name: Warehouse; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Warehouse" (warehouse_id, warehouse_name, address, street, province, district, zip, warehouse_phone, warehouse_email, open_office_hour, close_office_hour) FROM stdin;
\.
COPY public."Warehouse" (warehouse_id, warehouse_name, address, street, province, district, zip, warehouse_phone, warehouse_email, open_office_hour, close_office_hour) FROM '$$PATH$$/5067.dat';

--
-- Data for Name: WarehouseBranch; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."WarehouseBranch" (warehouse_id, branch_id, wb_id) FROM stdin;
\.
COPY public."WarehouseBranch" (warehouse_id, branch_id, wb_id) FROM '$$PATH$$/5075.dat';

--
-- Data for Name: Warranty; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Warranty" (warranty_id, product_id, warranty_length_month) FROM stdin;
\.
COPY public."Warranty" (warranty_id, product_id, warranty_length_month) FROM '$$PATH$$/5072.dat';

--
-- Data for Name: WarrantyRecord; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."WarrantyRecord" (warranty_record_id, order_id, product_id, warranty_record_date) FROM stdin;
\.
COPY public."WarrantyRecord" (warranty_record_id, order_id, product_id, warranty_record_date) FROM '$$PATH$$/5068.dat';

--
-- Name: MemberAddress_mem_add_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."MemberAddress_mem_add_id_seq"', 100, true);


--
-- Name: WarehouseBranch_wb_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."WarehouseBranch_wb_id_seq"', 5, true);


--
-- Name: Address Address_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Address"
    ADD CONSTRAINT "Address_pkey" PRIMARY KEY (address_id);


--
-- Name: Branch Branch_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Branch"
    ADD CONSTRAINT "Branch_pkey" PRIMARY KEY (branch_id);


--
-- Name: Category Category_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Category"
    ADD CONSTRAINT "Category_pkey" PRIMARY KEY (category_id);


--
-- Name: Color Color_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Color"
    ADD CONSTRAINT "Color_pkey" PRIMARY KEY (color_id);


--
-- Name: Employee Employee_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Employee"
    ADD CONSTRAINT "Employee_pkey" PRIMARY KEY (employee_id);


--
-- Name: Giftcard Giftcard_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Giftcard"
    ADD CONSTRAINT "Giftcard_pkey" PRIMARY KEY (giftcard_id);


--
-- Name: MemberAddress MemberAddress_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."MemberAddress"
    ADD CONSTRAINT "MemberAddress_pkey" PRIMARY KEY (mem_add_id);


--
-- Name: Member Member_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Member"
    ADD CONSTRAINT "Member_pkey" PRIMARY KEY (member_id);


--
-- Name: OrderStatus OrderStatus_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."OrderStatus"
    ADD CONSTRAINT "OrderStatus_pkey" PRIMARY KEY (order_id);


--
-- Name: Order Order_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Order"
    ADD CONSTRAINT "Order_pkey" PRIMARY KEY (order_id);


--
-- Name: OrderType Order_type_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."OrderType"
    ADD CONSTRAINT "Order_type_pkey" PRIMARY KEY (order_type_id);


--
-- Name: Payment Payment_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Payment"
    ADD CONSTRAINT "Payment_pkey" PRIMARY KEY (payment_id);


--
-- Name: PointLog PointLog_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."PointLog"
    ADD CONSTRAINT "PointLog_pkey" PRIMARY KEY (log_id);


--
-- Name: Position Position_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Position"
    ADD CONSTRAINT "Position_pkey" PRIMARY KEY (position_id);


--
-- Name: PriceHistory PriceHistory_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."PriceHistory"
    ADD CONSTRAINT "PriceHistory_pkey" PRIMARY KEY (product_id, start_date);


--
-- Name: ProductCategory ProductCategory_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ProductCategory"
    ADD CONSTRAINT "ProductCategory_pkey" PRIMARY KEY (product_id, subcategory_id);


--
-- Name: ProductOrder Product_Order_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ProductOrder"
    ADD CONSTRAINT "Product_Order_pkey" PRIMARY KEY ("Product_Order_id");


--
-- Name: ProductOrderReturn Product_order_return_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ProductOrderReturn"
    ADD CONSTRAINT "Product_order_return_pkey" PRIMARY KEY (product_order_id);


--
-- Name: Product Product_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Product"
    ADD CONSTRAINT "Product_pkey" PRIMARY KEY (product_id);


--
-- Name: PromotionType PromotionType_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."PromotionType"
    ADD CONSTRAINT "PromotionType_pkey" PRIMARY KEY (promotion_type_id);


--
-- Name: Promotion Promotion_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Promotion"
    ADD CONSTRAINT "Promotion_pkey" PRIMARY KEY (promotion_id);


--
-- Name: ShippingMethod Shipping_method_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ShippingMethod"
    ADD CONSTRAINT "Shipping_method_pkey" PRIMARY KEY (shipping_method_id);


--
-- Name: Status Status_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Status"
    ADD CONSTRAINT "Status_pkey" PRIMARY KEY (status_id);


--
-- Name: Stock Stock_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Stock"
    ADD CONSTRAINT "Stock_pkey" PRIMARY KEY (stock_record_id);


--
-- Name: SubCategory_1 SubCategory_1_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SubCategory_1"
    ADD CONSTRAINT "SubCategory_1_pkey" PRIMARY KEY (subcategory_id);


--
-- Name: SubCategory_2_1 SubCategory_2_1_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SubCategory_2_1"
    ADD CONSTRAINT "SubCategory_2_1_pkey" PRIMARY KEY ("SubCat_2_id", "SubCat_1_id");


--
-- Name: SubCategory_2 SubCategory_2_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SubCategory_2"
    ADD CONSTRAINT "SubCategory_2_pkey" PRIMARY KEY (subcategory_id);


--
-- Name: SubCategory_3_2 SubCategory_3_2_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SubCategory_3_2"
    ADD CONSTRAINT "SubCategory_3_2_pkey" PRIMARY KEY ("SubCat_3_id", "SubCat_2_id");


--
-- Name: SubCategory_3 SubCategory_3_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SubCategory_3"
    ADD CONSTRAINT "SubCategory_3_pkey" PRIMARY KEY (subcategory_id);


--
-- Name: SubCategory_4_3 SubCategory_4_3_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SubCategory_4_3"
    ADD CONSTRAINT "SubCategory_4_3_pkey" PRIMARY KEY ("SubCat_4_id", "SubCat_3_id");


--
-- Name: SubCategory_4 SubCategory_4_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SubCategory_4"
    ADD CONSTRAINT "SubCategory_4_pkey" PRIMARY KEY (subcategory_id);


--
-- Name: WarehouseBranch WarehouseBranch_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."WarehouseBranch"
    ADD CONSTRAINT "WarehouseBranch_pkey" PRIMARY KEY (wb_id);


--
-- Name: Warehouse Warehouse_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Warehouse"
    ADD CONSTRAINT "Warehouse_pkey" PRIMARY KEY (warehouse_id);


--
-- Name: Warranty Warranty_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Warranty"
    ADD CONSTRAINT "Warranty_pkey" PRIMARY KEY (warranty_id, product_id);


--
-- Name: WarrantyRecord Warranty_record_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."WarrantyRecord"
    ADD CONSTRAINT "Warranty_record_pkey" PRIMARY KEY (warranty_record_id);


--
-- Name: CatSubCat CatSubCat_Category_category_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."CatSubCat"
    ADD CONSTRAINT "CatSubCat_Category_category_id_fkey" FOREIGN KEY ("Category_category_id") REFERENCES public."Category"(category_id) NOT VALID;


--
-- Name: CatSubCat CatSubCat_SubCategory_1_subcategory_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."CatSubCat"
    ADD CONSTRAINT "CatSubCat_SubCategory_1_subcategory_id_fkey" FOREIGN KEY ("SubCategory_1_subcategory_id") REFERENCES public."SubCategory_1"(subcategory_id) NOT VALID;


--
-- Name: Employee Employee_position_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Employee"
    ADD CONSTRAINT "Employee_position_id_fkey" FOREIGN KEY (position_id) REFERENCES public."Position"(position_id) NOT VALID;


--
-- Name: Employee Employee_position_id_fkey1; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Employee"
    ADD CONSTRAINT "Employee_position_id_fkey1" FOREIGN KEY (position_id) REFERENCES public."Position"(position_id) NOT VALID;


--
-- Name: MemberAddress MemberAddress_address_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."MemberAddress"
    ADD CONSTRAINT "MemberAddress_address_id_fkey" FOREIGN KEY (address_id) REFERENCES public."Address"(address_id) NOT VALID;


--
-- Name: MemberAddress MemberAddress_member_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."MemberAddress"
    ADD CONSTRAINT "MemberAddress_member_id_fkey" FOREIGN KEY (member_id) REFERENCES public."Member"(member_id) NOT VALID;


--
-- Name: OrderStatus OrderStatus_order_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."OrderStatus"
    ADD CONSTRAINT "OrderStatus_order_id_fkey" FOREIGN KEY (order_id) REFERENCES public."Order"(order_id) NOT VALID;


--
-- Name: OrderStatus OrderStatus_status_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."OrderStatus"
    ADD CONSTRAINT "OrderStatus_status_id_fkey" FOREIGN KEY (status_id) REFERENCES public."Status"(status_id) NOT VALID;


--
-- Name: Order Order_employee_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Order"
    ADD CONSTRAINT "Order_employee_id_fkey" FOREIGN KEY (employee_id) REFERENCES public."Employee"(employee_id) NOT VALID;


--
-- Name: Order Order_employee_id_fkey1; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Order"
    ADD CONSTRAINT "Order_employee_id_fkey1" FOREIGN KEY (employee_id) REFERENCES public."Employee"(employee_id) NOT VALID;


--
-- Name: Order Order_giftcard_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Order"
    ADD CONSTRAINT "Order_giftcard_id_fkey" FOREIGN KEY (giftcard_id) REFERENCES public."Giftcard"(giftcard_id) NOT VALID;


--
-- Name: Order Order_mem_ad_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Order"
    ADD CONSTRAINT "Order_mem_ad_id_fkey" FOREIGN KEY (mem_add_id) REFERENCES public."MemberAddress"(mem_add_id) NOT VALID;


--
-- Name: Order Order_member_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Order"
    ADD CONSTRAINT "Order_member_id_fkey" FOREIGN KEY (member_id) REFERENCES public."Member"(member_id) NOT VALID;


--
-- Name: Order Order_order_type_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Order"
    ADD CONSTRAINT "Order_order_type_id_fkey" FOREIGN KEY (order_type_id) REFERENCES public."OrderType"(order_type_id) NOT VALID;


--
-- Name: Order Order_order_type_id_fkey1; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Order"
    ADD CONSTRAINT "Order_order_type_id_fkey1" FOREIGN KEY (order_type_id) REFERENCES public."OrderType"(order_type_id) NOT VALID;


--
-- Name: Order Order_payment_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Order"
    ADD CONSTRAINT "Order_payment_id_fkey" FOREIGN KEY (payment_id) REFERENCES public."Payment"(payment_id) NOT VALID;


--
-- Name: Order Order_payment_id_fkey1; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Order"
    ADD CONSTRAINT "Order_payment_id_fkey1" FOREIGN KEY (payment_id) REFERENCES public."Payment"(payment_id) NOT VALID;


--
-- Name: Order Order_shipping_method_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Order"
    ADD CONSTRAINT "Order_shipping_method_id_fkey" FOREIGN KEY (shipping_method_id) REFERENCES public."ShippingMethod"(shipping_method_id) NOT VALID;


--
-- Name: Order Order_shipping_method_id_fkey1; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Order"
    ADD CONSTRAINT "Order_shipping_method_id_fkey1" FOREIGN KEY (shipping_method_id) REFERENCES public."ShippingMethod"(shipping_method_id) NOT VALID;


--
-- Name: PointLog PointLog_remark_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."PointLog"
    ADD CONSTRAINT "PointLog_remark_fkey" FOREIGN KEY (remark) REFERENCES public."Order"(order_id) NOT VALID;


--
-- Name: PriceHistory PriceHistory_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."PriceHistory"
    ADD CONSTRAINT "PriceHistory_product_id_fkey" FOREIGN KEY (product_id) REFERENCES public."Product"(product_id) NOT VALID;


--
-- Name: PriceHistory PriceHistory_product_id_fkey1; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."PriceHistory"
    ADD CONSTRAINT "PriceHistory_product_id_fkey1" FOREIGN KEY (product_id) REFERENCES public."Product"(product_id) NOT VALID;


--
-- Name: ProductOrder Product_Order_Order_order_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ProductOrder"
    ADD CONSTRAINT "Product_Order_Order_order_id_fkey" FOREIGN KEY ("Order_order_id") REFERENCES public."Order"(order_id) NOT VALID;


--
-- Name: ProductOrder Product_Order_Product_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ProductOrder"
    ADD CONSTRAINT "Product_Order_Product_product_id_fkey" FOREIGN KEY ("Product_product_id") REFERENCES public."Product"(product_id) NOT VALID;


--
-- Name: ProductOrder Product_Order_branch_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ProductOrder"
    ADD CONSTRAINT "Product_Order_branch_id_fkey" FOREIGN KEY (branch_id) REFERENCES public."Branch"(branch_id) NOT VALID;


--
-- Name: Product Product_color_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Product"
    ADD CONSTRAINT "Product_color_id_fkey" FOREIGN KEY (color_id) REFERENCES public."Color"(color_id) NOT VALID;


--
-- Name: Product Product_color_id_fkey1; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Product"
    ADD CONSTRAINT "Product_color_id_fkey1" FOREIGN KEY (color_id) REFERENCES public."Color"(color_id) NOT VALID;


--
-- Name: ProductOrderReturn Product_order_return_product_order_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ProductOrderReturn"
    ADD CONSTRAINT "Product_order_return_product_order_id_fkey" FOREIGN KEY (product_order_id) REFERENCES public."ProductOrder"("Product_Order_id") NOT VALID;


--
-- Name: Stock Stock_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Stock"
    ADD CONSTRAINT "Stock_product_id_fkey" FOREIGN KEY (product_id) REFERENCES public."Product"(product_id) NOT VALID;


--
-- Name: Stock Stock_product_id_fkey1; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Stock"
    ADD CONSTRAINT "Stock_product_id_fkey1" FOREIGN KEY (product_id) REFERENCES public."Product"(product_id) NOT VALID;


--
-- Name: Stock Stock_warehouse_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Stock"
    ADD CONSTRAINT "Stock_warehouse_id_fkey" FOREIGN KEY (warehouse_id) REFERENCES public."Warehouse"(warehouse_id) NOT VALID;


--
-- Name: SubCategory_2_1 SubCategory_2_1_SubCat_1_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SubCategory_2_1"
    ADD CONSTRAINT "SubCategory_2_1_SubCat_1_id_fkey" FOREIGN KEY ("SubCat_1_id") REFERENCES public."SubCategory_1"(subcategory_id) NOT VALID;


--
-- Name: SubCategory_2_1 SubCategory_2_1_SubCat_2_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SubCategory_2_1"
    ADD CONSTRAINT "SubCategory_2_1_SubCat_2_id_fkey" FOREIGN KEY ("SubCat_2_id") REFERENCES public."SubCategory_2"(subcategory_id) NOT VALID;


--
-- Name: SubCategory_3_2 SubCategory_3_2_SubCat_2_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SubCategory_3_2"
    ADD CONSTRAINT "SubCategory_3_2_SubCat_2_id_fkey" FOREIGN KEY ("SubCat_2_id") REFERENCES public."SubCategory_2"(subcategory_id) NOT VALID;


--
-- Name: SubCategory_3_2 SubCategory_3_2_SubCat_3_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SubCategory_3_2"
    ADD CONSTRAINT "SubCategory_3_2_SubCat_3_id_fkey" FOREIGN KEY ("SubCat_3_id") REFERENCES public."SubCategory_3"(subcategory_id) NOT VALID;


--
-- Name: SubCategory_4_3 SubCategory_4_3_SubCat_3_id_fkey1; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SubCategory_4_3"
    ADD CONSTRAINT "SubCategory_4_3_SubCat_3_id_fkey1" FOREIGN KEY ("SubCat_3_id") REFERENCES public."SubCategory_3"(subcategory_id) NOT VALID;


--
-- Name: SubCategory_4_3 SubCategory_4_3_SubCat_4_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SubCategory_4_3"
    ADD CONSTRAINT "SubCategory_4_3_SubCat_4_id_fkey" FOREIGN KEY ("SubCat_4_id") REFERENCES public."SubCategory_4"(subcategory_id) NOT VALID;


--
-- Name: WarehouseBranch WarehouseBranch_branch_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."WarehouseBranch"
    ADD CONSTRAINT "WarehouseBranch_branch_id_fkey" FOREIGN KEY (branch_id) REFERENCES public."Branch"(branch_id) NOT VALID;


--
-- Name: WarehouseBranch WarehouseBranch_warehouse_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."WarehouseBranch"
    ADD CONSTRAINT "WarehouseBranch_warehouse_id_fkey" FOREIGN KEY (warehouse_id) REFERENCES public."Warehouse"(warehouse_id) NOT VALID;


--
-- Name: WarrantyRecord Warranty_record_order_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."WarrantyRecord"
    ADD CONSTRAINT "Warranty_record_order_id_fkey" FOREIGN KEY (order_id) REFERENCES public."Order"(order_id) NOT VALID;


--
-- Name: WarrantyRecord Warranty_record_order_id_fkey1; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."WarrantyRecord"
    ADD CONSTRAINT "Warranty_record_order_id_fkey1" FOREIGN KEY (order_id) REFERENCES public."Order"(order_id) NOT VALID;


--
-- Name: WarrantyRecord Warranty_record_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."WarrantyRecord"
    ADD CONSTRAINT "Warranty_record_product_id_fkey" FOREIGN KEY (product_id) REFERENCES public."Product"(product_id) NOT VALID;


--
-- Name: WarrantyRecord Warranty_record_product_id_fkey1; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."WarrantyRecord"
    ADD CONSTRAINT "Warranty_record_product_id_fkey1" FOREIGN KEY (product_id) REFERENCES public."Product"(product_id) NOT VALID;


--
-- PostgreSQL database dump complete
--

